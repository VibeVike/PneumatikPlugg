Got Bored and decided to code an entire website to study for one exam
